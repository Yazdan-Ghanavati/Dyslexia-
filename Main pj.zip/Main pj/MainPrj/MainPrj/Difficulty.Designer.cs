﻿namespace MainPrj
{
    partial class Difficulty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbEasy = new System.Windows.Forms.RadioButton();
            this.rbModerate = new System.Windows.Forms.RadioButton();
            this.rbHard = new System.Windows.Forms.RadioButton();
            this.lbDifficulty = new System.Windows.Forms.Label();
            this.btnReturnDiff = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rbEasy
            // 
            this.rbEasy.AutoSize = true;
            this.rbEasy.Checked = true;
            this.rbEasy.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.rbEasy.Location = new System.Drawing.Point(185, 113);
            this.rbEasy.Name = "rbEasy";
            this.rbEasy.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.rbEasy.Size = new System.Drawing.Size(64, 35);
            this.rbEasy.TabIndex = 0;
            this.rbEasy.TabStop = true;
            this.rbEasy.Text = "آسان";
            this.rbEasy.UseVisualStyleBackColor = true;
            this.rbEasy.CheckedChanged += new System.EventHandler(this.rbEasy_CheckedChanged);
            // 
            // rbModerate
            // 
            this.rbModerate.AutoSize = true;
            this.rbModerate.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.rbModerate.Location = new System.Drawing.Point(176, 154);
            this.rbModerate.Name = "rbModerate";
            this.rbModerate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.rbModerate.Size = new System.Drawing.Size(73, 35);
            this.rbModerate.TabIndex = 1;
            this.rbModerate.Text = "متوسط";
            this.rbModerate.UseVisualStyleBackColor = true;
            this.rbModerate.CheckedChanged += new System.EventHandler(this.rbModerate_CheckedChanged);
            // 
            // rbHard
            // 
            this.rbHard.AutoSize = true;
            this.rbHard.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.rbHard.Location = new System.Drawing.Point(182, 195);
            this.rbHard.Name = "rbHard";
            this.rbHard.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.rbHard.Size = new System.Drawing.Size(67, 35);
            this.rbHard.TabIndex = 2;
            this.rbHard.Text = "سخت";
            this.rbHard.UseVisualStyleBackColor = true;
            this.rbHard.CheckedChanged += new System.EventHandler(this.rbHard_CheckedChanged);
            // 
            // lbDifficulty
            // 
            this.lbDifficulty.AutoSize = true;
            this.lbDifficulty.Font = new System.Drawing.Font("B Roya", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbDifficulty.Location = new System.Drawing.Point(310, 31);
            this.lbDifficulty.Name = "lbDifficulty";
            this.lbDifficulty.Size = new System.Drawing.Size(204, 35);
            this.lbDifficulty.TabIndex = 3;
            this.lbDifficulty.Text = ":سختی بازی را مشخص کنید";
            // 
            // btnReturnDiff
            // 
            this.btnReturnDiff.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnReturnDiff.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnReturnDiff.Location = new System.Drawing.Point(341, 247);
            this.btnReturnDiff.Name = "btnReturnDiff";
            this.btnReturnDiff.Size = new System.Drawing.Size(164, 50);
            this.btnReturnDiff.TabIndex = 4;
            this.btnReturnDiff.Text = "بازگشت به صفحه اصلی";
            this.btnReturnDiff.UseVisualStyleBackColor = true;
            this.btnReturnDiff.Click += new System.EventHandler(this.btnReturnDiff_Click);
            // 
            // Difficulty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(559, 339);
            this.Controls.Add(this.btnReturnDiff);
            this.Controls.Add(this.lbDifficulty);
            this.Controls.Add(this.rbHard);
            this.Controls.Add(this.rbModerate);
            this.Controls.Add(this.rbEasy);
            this.Name = "Difficulty";
            this.Text = "Difficulty";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbEasy;
        private System.Windows.Forms.RadioButton rbModerate;
        private System.Windows.Forms.RadioButton rbHard;
        private System.Windows.Forms.Label lbDifficulty;
        private System.Windows.Forms.Button btnReturnDiff;
    }
}