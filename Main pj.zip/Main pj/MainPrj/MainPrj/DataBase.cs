﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace MainPrj
{
    public partial class DataBase : Form
    {
        public int count = 0;
        public string tbName_in_DataBase;
        public string tbLast_in_DataBase;
        public int tbIdNum_in_DataBase;
        public int tbAge_in_DataBase;
        public DataBase()
        {
            InitializeComponent();
        }
       
        private void DataBase_Load(object sender, EventArgs e)
        {

        }

        private void btnTransfer_Click(object sender, EventArgs e)
        {


            StreamWriter Sw;
            string Dpath = "C:\\Users\\lenovo\\Documents\\PROJECT_CSHARP\\DataBase.txt";
            if (File.Exists(Dpath))
                Sw = File.AppendText(Dpath);
            else
                Sw = File.CreateText(Dpath);
            
            Sw.WriteLine("Name: " + tbName.Text);
            Sw.WriteLine("LastName: " + tbLastName.Text);
            Sw.WriteLine("Id Number: " + tbIdNum.Text);
            Sw.WriteLine("Age: " + tbAge.Text);
            //Sw.WriteLine(DateTime.Now);
            Sw.Close();

            tbName_in_DataBase = tbName.Text;
            tbLast_in_DataBase = tbLastName.Text;
            try
            {
                tbIdNum_in_DataBase = Convert.ToInt32(tbIdNum.Text);
                tbAge_in_DataBase = Convert.ToInt32(tbAge.Text);
            }
            catch(Exception E) { MessageBox.Show(E.ToString()); }
            count = 1;
            MessageBox.Show("اطلاعات منتقل شد");
            tbName.Clear();
            tbLastName.Clear();
            tbIdNum.Clear();
            tbAge.Clear();
        }
    }
}
