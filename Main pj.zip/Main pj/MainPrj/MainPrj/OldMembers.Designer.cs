﻿namespace MainPrj
{
    partial class OldMembers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LBoxData = new System.Windows.Forms.ListBox();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnOldMemChoose = new System.Windows.Forms.Button();
            this.btnRetuenOldMem = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // LBoxData
            // 
            this.LBoxData.Font = new System.Drawing.Font("B Roya", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.LBoxData.FormattingEnabled = true;
            this.LBoxData.ItemHeight = 27;
            this.LBoxData.Location = new System.Drawing.Point(12, 24);
            this.LBoxData.Name = "LBoxData";
            this.LBoxData.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LBoxData.Size = new System.Drawing.Size(176, 220);
            this.LBoxData.TabIndex = 0;
            this.LBoxData.SelectedIndexChanged += new System.EventHandler(this.LBoxData_SelectedIndexChanged);
            // 
            // btnDel
            // 
            this.btnDel.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnDel.Location = new System.Drawing.Point(33, 265);
            this.btnDel.Name = "btnDel";
            this.btnDel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnDel.Size = new System.Drawing.Size(139, 37);
            this.btnDel.TabIndex = 1;
            this.btnDel.Text = "حذف کاربر";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnOldMemChoose
            // 
            this.btnOldMemChoose.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnOldMemChoose.Location = new System.Drawing.Point(262, 265);
            this.btnOldMemChoose.Name = "btnOldMemChoose";
            this.btnOldMemChoose.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnOldMemChoose.Size = new System.Drawing.Size(125, 37);
            this.btnOldMemChoose.TabIndex = 2;
            this.btnOldMemChoose.Text = "انتخاب کاربر";
            this.toolTip1.SetToolTip(this.btnOldMemChoose, "برای انتخاب کاربر تنها نام را انتخاب کنید");
            this.btnOldMemChoose.UseVisualStyleBackColor = true;
            this.btnOldMemChoose.Click += new System.EventHandler(this.btnOldMemChoose_Click);
            // 
            // btnRetuenOldMem
            // 
            this.btnRetuenOldMem.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnRetuenOldMem.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnRetuenOldMem.Location = new System.Drawing.Point(12, 332);
            this.btnRetuenOldMem.Name = "btnRetuenOldMem";
            this.btnRetuenOldMem.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnRetuenOldMem.Size = new System.Drawing.Size(176, 46);
            this.btnRetuenOldMem.TabIndex = 3;
            this.btnRetuenOldMem.Text = "بازگشت به فرم اصلی";
            this.btnRetuenOldMem.UseVisualStyleBackColor = true;
            // 
            // OldMembers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(731, 419);
            this.Controls.Add(this.btnRetuenOldMem);
            this.Controls.Add(this.btnOldMemChoose);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.LBoxData);
            this.Name = "OldMembers";
            this.Text = "مشخصات کاربر";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox LBoxData;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnOldMemChoose;
        private System.Windows.Forms.Button btnRetuenOldMem;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}