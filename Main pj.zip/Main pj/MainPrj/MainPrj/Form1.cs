﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MainPrj
{

    public partial class Form1 : Form
    {

        int GC = 0;//for random keyboard counter
        bool FirstTime = true;
        OldMembers OL = new OldMembers();
        bool IsLvlChnge = false;
        string Dpath = "C:\\Users\\lenovo\\Documents\\PROJECT_CSHARP\\DataBase.txt";
        StreamReader Sr;
        StreamWriter Sw;
        int t = 0;//baraye timer baraye sathe bazi
        int NPoitns = 0;
        int PPoints = 0;
        Difficulty Dif;
        DataBase Db = new DataBase();

        int i;//baraye sefr kardane emtiazt baad az feshordane kilide start pas az karbar jadid
        string Hardship = "آسان";

        void disp() {
            btnAlef.Visible = true;
            btnBe.Visible = true;
            btnPe.Visible = true;
            btnTe.Visible = true;
            btnSe.Visible = true;
            btnJim.Visible = true;
            btnChe.Visible = true;
            btnHe.Visible = true;
            btnKhe.Visible = true;
            btnDal.Visible = true;
            btnZal.Visible = true;
            btnRe.Visible = true;
            btnZe.Visible = true;
            btnZhe.Visible = true;
            btnSin.Visible = true;
            btnShin.Visible = true;
            btnSad.Visible = true;
            btnZad.Visible = true;
            btnTa.Visible = true;
            btnZa.Visible = true;
            btnEin.Visible = true;
            btnGhein.Visible = true;
            btnFe.Visible = true;
            btnGhaf.Visible = true;
            btnKaf.Visible = true;
            btnGaf.Visible = true;
            btnLam.Visible = true;
            btnMim.Visible = true;
            btnNoon.Visible = true;
            btnVav.Visible = true;
            btnHee.Visible = true;
            btnYe.Visible = true;
            btnSpace.Visible = true;
            btnClear.Visible = true;
        }
        void hide() {
            btnAlef.Visible = false;
            btnBe.Visible = false;
            btnPe.Visible = false;
            btnTe.Visible = false;
            btnSe.Visible = false;
            btnJim.Visible = false;
            btnChe.Visible = false;
            btnHe.Visible = false;
            btnKhe.Visible = false;
            btnDal.Visible = false;
            btnZal.Visible = false;
            btnRe.Visible = false;
            btnZe.Visible = false;
            btnZhe.Visible = false;
            btnSin.Visible = false;
            btnShin.Visible = false;
            btnSad.Visible = false;
            btnZad.Visible = false;
            btnTa.Visible = false;
            btnZa.Visible = false;
            btnEin.Visible = false;
            btnGhein.Visible = false;
            btnFe.Visible = false;
            btnGhaf.Visible = false;
            btnKaf.Visible = false;
            btnGaf.Visible = false;
            btnLam.Visible = false;
            btnMim.Visible = false;
            btnNoon.Visible = false;
            btnVav.Visible = false;
            btnHee.Visible = false;
            btnYe.Visible = false;
            btnSpace.Visible = false;
            btnClear.Visible = false;
        }


        void hideK()
        {
            btn1.Visible = false;
            btn2.Visible = false;
            btn3.Visible = false;
            btn4.Visible = false;
            btn5.Visible = false;
            btn6.Visible = false;
            btn7.Visible = false;
            btn8.Visible = false;
            btn9.Visible = false;
            btn10.Visible = false;
        }

        void clearK()
        {
            btn1.Text = "kw";
            btn2.Text = "kw";
            btn3.Text = "kw";
            btn4.Text = "kw";
            btn5.Text = "kw";
            btn6.Text = "kw";
            btn7.Text = "kw";
            btn8.Text = "kw";
            btn9.Text = "kw";
            btn10.Text = "kw";
        }
        void NullCheck()
        {
            if (btn1.Text == "kw") btn1.Visible = false;
            if (btn2.Text == "kw") btn2.Visible = false;
            if (btn3.Text == "kw") btn3.Visible = false;
            if (btn4.Text == "kw") btn4.Visible = false;
            if (btn5.Text == "kw") btn5.Visible = false;
            if (btn6.Text == "kw") btn6.Visible = false;
            if (btn7.Text == "kw") btn7.Visible = false;
            if (btn8.Text == "kw") btn8.Visible = false;
            if (btn9.Text == "kw") btn9.Visible = false;
            if (btn10.Text == "kw") btn10.Visible = false;
        }
        void dispK()
        {
            btn1.Visible = true;
            btn2.Visible = true;
            btn3.Visible = true;
            btn4.Visible = true;
            btn5.Visible = true;
            btn6.Visible = true;
            btn7.Visible = true;
            btn8.Visible = true;
            btn9.Visible = true;
            btn10.Visible = true;
        }
        public Form1()
        {

            InitializeComponent();
            btnPlay.Visible = false;
            AxWmPlayer.Visible = false;
            lbRead.Visible = false;
            tbCheck.Visible = false;
            lbGuess.Visible = false;
            btnReadWord.Visible = false;
            btnReadWord.Enabled = false;
            btnGuessCheck.Visible = false;
            btnGuessCheck.Enabled = false;
            lbPosPoints.Visible = false;
            lbNegPoints.Visible = false;
            btnStart.Visible = false;
            MessageBox.Show("به بازی خوش آمدید لطفا مشخصات خود را از منوی کاربر جدید وارد کنید");
        }
        
        private void btnReadWord_Click(object sender, EventArgs e)
        {
            FirstTime = false;
           
            clearK();

           

            btnPlay.Visible = true;
                AxWmPlayer.Visible = true;
                if (lbRead.Text == "اختاپوس")
                {
                    AxWmPlayer.URL = "C:\\Users\\lenovo\\Downloads\\Music\\Recording.wmv";

                }

            lbRead.Visible = false;
            lbGuess.Visible = false;
            tbCheck.Visible = false;
            tbCheck.Enabled = false;
            btnStart.Enabled = false;
            btnReadWord.Visible = false;
            btnGuessCheck.Visible = false;
            btnGuessCheck.Enabled = false;


            btnStart.Text = "شروع مجدد";

                lbNegPoints.Text = "امتیاز منفی: " + NPoitns.ToString();
                lbPosPoints.Text = "امتیاز مثبت: " + PPoints.ToString();


                try
                {
                    lbRead.Text = Sr.ReadLine();
                    btnReadWord.Text = "کلمه بعدی";
                if (IsLvlChnge)
                {
                    DialogResult RandKeyPad = MessageBox.Show("آیا می خواهید از کیبورد رندوم استفاده کنید؟", "انتخاب نوع کیبورد", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (RandKeyPad == DialogResult.Yes)
                    {
                        char[] GuessBtn = lbRead.Text.ToCharArray();
                        GC = GuessBtn.Length;

                        while (true)
                        {
                            if (GC == 0) break; btn1.Text = GuessBtn[0].ToString(); GC--;
                            if (GC == 0) break; btn2.Text = GuessBtn[1].ToString(); GC--;
                            if (GC == 0) break; btn3.Text = GuessBtn[2].ToString(); GC--;
                            if (GC == 0) break; btn4.Text = GuessBtn[3].ToString(); GC--;
                            if (GC == 0) break; btn5.Text = GuessBtn[4].ToString(); GC--;
                            if (GC == 0) break; btn6.Text = GuessBtn[5].ToString(); GC--;
                            if (GC == 0) break; btn7.Text = GuessBtn[6].ToString(); GC--;
                            if (GC == 0) break; btn8.Text = GuessBtn[7].ToString(); GC--;
                            if (GC == 0) break; btn9.Text = GuessBtn[8].ToString(); GC--;
                            if (GC == 0) break; btn10.Text = GuessBtn[9].ToString(); GC--;

                        }
                        lbRead.Visible = true;
                        lbGuess.Visible = true;
                        tbCheck.Visible = true;
                        tbCheck.Enabled = true;
                        btnStart.Enabled = false;

                        btnReadWord.Visible = true;
                        btnGuessCheck.Visible = true;
                        btnGuessCheck.Enabled = true;

                        dispK();
                        NullCheck();
                    }

                    else
                    {
                        lbRead.Visible = true;
                        lbGuess.Visible = true;
                        tbCheck.Visible = true;
                        tbCheck.Enabled = true;
                        btnStart.Enabled = false;

                        btnReadWord.Visible = true;
                        btnGuessCheck.Visible = true;
                        btnGuessCheck.Enabled = true;

                        //نمایش صفحه کلید
                        disp();
                    }
                    timer1.Start();
                }

                else
                {
                    if (!OL.IsOldUser)
                        Hardship = "آسان";
                    else
                    {
                        Hardship = OL.omh;

                    }
                    DialogResult RandKeyPad = MessageBox.Show("آیا می خواهید از کیبورد رندوم استفاده کنید؟", "انتخاب نوع کیبورد", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (RandKeyPad == DialogResult.Yes)
                    {
                        char[] GuessBtn = lbRead.Text.ToCharArray();
                        GC = GuessBtn.Length;

                        while (true)
                        {
                            if (GC == 0) break; btn1.Text = GuessBtn[0].ToString(); GC--;
                            if (GC == 0) break; btn2.Text = GuessBtn[1].ToString(); GC--;
                            if (GC == 0) break; btn3.Text = GuessBtn[2].ToString(); GC--;
                            if (GC == 0) break; btn4.Text = GuessBtn[3].ToString(); GC--;
                            if (GC == 0) break; btn5.Text = GuessBtn[4].ToString(); GC--;
                            if (GC == 0) break; btn6.Text = GuessBtn[5].ToString(); GC--;
                            if (GC == 0) break; btn7.Text = GuessBtn[6].ToString(); GC--;
                            if (GC == 0) break; btn8.Text = GuessBtn[7].ToString(); GC--;
                            if (GC == 0) break; btn9.Text = GuessBtn[8].ToString(); GC--;
                            if (GC == 0) break; btn10.Text = GuessBtn[9].ToString(); GC--;

                        }
                        lbRead.Visible = true;
                        lbGuess.Visible = true;
                        tbCheck.Visible = true;
                        tbCheck.Enabled = true;
                        btnStart.Enabled = false;

                        btnReadWord.Visible = true;
                        btnGuessCheck.Visible = true;
                        btnGuessCheck.Enabled = true;

                        dispK();
                        NullCheck();
                    }

                    else
                    {
                        lbRead.Visible = true;
                        lbGuess.Visible = true;
                        tbCheck.Visible = true;
                        tbCheck.Enabled = true;
                        btnStart.Enabled = false;

                        btnReadWord.Visible = true;
                        btnGuessCheck.Visible = true;
                        btnGuessCheck.Enabled = true;

                        //نمایش صفحه کلید
                        disp();
                    }
                    timer1.Start();
                }
                }
                catch { }


            
            
            btnReadWord.Visible = false;
            }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            t++;


            if (Hardship == "متوسط")
            {
                if (t == 30)
                {

                    lbRead.Visible = false;

                }
                if (t == 151)
                {

                    if (lbRead.Text != lbGuess.Text)
                        NPoitns++;
                    else
                        PPoints++;
                    MessageBox.Show("فرصت شما پایان یافت،دوباره تلاش کنید");
                    lbNegPoints.Text = "امتیاز منفی: " + NPoitns.ToString();
                    lbPosPoints.Text = "امتیاز مثبت: " + PPoints.ToString();

                    OL.IsOldUser = false;
                    btnPlay.Visible = false;
                    AxWmPlayer.Visible = false;
                    btnReadWord.Visible = false;
                    hide();
                    hideK();
                    btnGuessCheck.Visible = false;
                    lbGuess.Visible = false;
                    btnReadWord.Visible = true;
                    tbCheck.Enabled = false;
                    t = 0;
                    timer1.Stop();
                }
            }//حالت متوسط
            if (Hardship == "سخت")
            {
                if (t == 10)
                {

                    lbRead.Visible = false;

                }
                if (t == 101)
                {

                    if (lbRead.Text != lbGuess.Text)
                        NPoitns++;
                    else
                        PPoints++;
                    MessageBox.Show("فرصت شما پایان یافت،دوباره تلاش کنید");
                    lbNegPoints.Text = "امتیاز منفی: " + NPoitns.ToString();
                    lbPosPoints.Text = "امتیاز مثبت: " + PPoints.ToString();

                    OL.IsOldUser = false;
                    btnPlay.Visible = false;
                    AxWmPlayer.Visible = false;
                    btnReadWord.Visible = false;
                    hide();
                    hideK();
                    btnGuessCheck.Visible = false;
                    lbGuess.Visible = false;
                    btnReadWord.Visible = true;
                    tbCheck.Enabled = false;
                    t = 0;
                    timer1.Stop();
                }
            }//حالت سخت
            else
            {
                if (t == 40)
                {

                    lbRead.Visible = false;

                }
                if (t == 201)
                {

                    if (lbRead.Text != lbGuess.Text)
                        NPoitns++;
                    else
                        PPoints++;
                    MessageBox.Show("فرصت شما پایان یافت،دوباره تلاش کنید");
                    lbNegPoints.Text = "امتیاز منفی: " + NPoitns.ToString();
                    lbPosPoints.Text = "امتیاز مثبت: " + PPoints.ToString();

                    OL.IsOldUser = false;
                    btnPlay.Visible = false;
                    AxWmPlayer.Visible = false;
                    btnReadWord.Visible = false;
                    hide();
                    hideK();
                    btnGuessCheck.Visible = false;
                    lbGuess.Visible = false;
                    btnReadWord.Visible = true;
                    tbCheck.Enabled = false;
                    t = 0;
                    timer1.Stop();
                }
            }//حالت آسان

        }
        private void btnAlef_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ا";
        }

        private void btnBe_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ب";
        }

        private void btnPe_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "پ";
        }

        private void btnTe_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ت";
        }

        private void btnSe_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ث";
        }

        private void btnJim_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ج";
        }

        private void btnChe_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "چ";
        }

        private void btnHe_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ح";
        }

        private void btnKhe_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "خ";
        }

        private void btnDal_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "د";
        }

        private void btnZal_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ذ";
        }

        private void btnRe_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ر";
        }

        private void btnZe_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ز";
        }

        private void btnZhe_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ژ";
        }

        private void btnSin_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "س";
        }

        private void btnShin_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ش";
        }

        private void btnSad_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ص";
        }

        private void btnZad_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ض";
        }

        private void btnTa_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ط";
        }

        private void btnZa_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ظ";
        }

        private void btnEin_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ع";
        }

        private void btnGhein_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "غ";
        }

        private void btnFe_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ف";
        }

        private void btnGhaf_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ق";
        }

        private void btnKaf_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ک";
        }

        private void btnGaf_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "گ";
        }

        private void btnLam_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ل";
        }

        private void btnMim_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "م";
        }

        private void btnNoon_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ن";
        }

        private void btnVav_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "و";
        }

        private void btnHee_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ه";
        }

        private void btnYe_Click(object sender, EventArgs e)
        {
            tbCheck.Text += "ی";
        }

        private void btnSpace_Click(object sender, EventArgs e)
        {
            tbCheck.Text += " ";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            tbCheck.Clear();
        }

        private void btnGuessCheck_Click(object sender, EventArgs e)
        {


            if (tbCheck.Text == lbRead.Text)
            {
                MessageBox.Show("درست حدس زدید");
                PPoints++;
            }
            else
            {
                MessageBox.Show("اشتباه حدس زدید");
                NPoitns++;
            }

            if (Sr.EndOfStream)
            {
                MessageBox.Show("end of file");
                btnStart.Enabled = true;
                btnReadWord.Enabled = false;
                btnGuessCheck.Enabled = false;


                hide();
                hideK();

                Sr.Close();
            }
            btnReadWord.Visible = true;
            hide();
            hideK();
            btnPlay.Visible = false;
            AxWmPlayer.Visible = false;

            lbNegPoints.Text = "امتیاز منفی: " + NPoitns.ToString();
            lbPosPoints.Text = "امتیاز مثبت: " + PPoints.ToString();

            lbRead.Text = "";

            t = 0;
            timer1.Stop();
            btnStart.Enabled = true;

            tbCheck.Enabled = false;
            btnGuessCheck.Enabled = false;
            lbGuess.Visible = false;
            tbCheck.Clear();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {


                btnReadWord.Visible = true;

                Sr = File.OpenText("C:\\Users\\lenovo\\Documents\\PROJECT_CSHARP\\DataPrj.txt");

                MessageBox.Show("برای نمایش کلمات گزینه نمایش را فشار دهید");
                //مخفی کردن صفحه نمایش
                hide();
                                

                if (i == 0)
                {
                    NPoitns = 0;
                    PPoints = 0;
                    i = 1;
                }


                btnStart.Text = "";
                btnReadWord.Text = "نمایش";
                btnReadWord.Visible = true;
                btnReadWord.Enabled = true;

                btnStart.Enabled = false;
            }
        
        private void خروجToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult Ex;
            Ex = MessageBox.Show("برای خروج از برنامه اطمینان دارید؟؟", "خروج", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Ex == DialogResult.Yes) {
                Dif = new Difficulty();
                if (!OL.IsOldUser)
                    Hardship = Dif.RbResult;
                else
                    Hardship = OL.omh;
                Sw = File.AppendText(Dpath);


                Sw.WriteLine("Difficulty: " + Hardship);
                Sw.WriteLine("Negative Points: " + NPoitns.ToString());
                Sw.WriteLine("Positive Points: " + PPoints.ToString());
                Sw.WriteLine("---------------------------");
                Sw.Close();


                this.Close();

            }
            else
                return;
        }
    
        private void کاربرجدیدToolStripMenuItem_Click(object sender, EventArgs e)
        {

            OL.IsOldUser = false;
            btnPlay.Visible = false;
            AxWmPlayer.Visible = false;
            btnReadWord.Visible = false;
            hide();
            hideK();
            if (!FirstTime)
            {
                Sw = File.AppendText(Dpath);

                Sw.WriteLine("Difficulty: " + Hardship);

                Sw.WriteLine("Negative Points: " + NPoitns.ToString());
                Sw.WriteLine("Positive Points: " + PPoints.ToString());
                Sw.WriteLine("---------------------------");
                Sw.Close();
            }

            if (Db.count == 1)
            {
                if (IsLvlChnge)
                {
                    
                    OL.Add(Db.tbName_in_DataBase, Db.tbLast_in_DataBase, Db.tbIdNum_in_DataBase, Db.tbAge_in_DataBase, Hardship, NPoitns, PPoints);
                    IsLvlChnge = false;
                }
                else
                {
                    Hardship = "آسان";

                   
                    OL.Add(Db.tbName_in_DataBase, Db.tbLast_in_DataBase, Db.tbIdNum_in_DataBase, Db.tbAge_in_DataBase, Hardship, NPoitns, PPoints);
                }

               

                
                }//db.count==1
            Db.count = 0;
            btnStart.Text = "شروع";
            i = 0;
            if (i == 0)
            {
                NPoitns = 0;
                PPoints = 0;
            }

            Db.ShowDialog();
            if (Db.tbName_in_DataBase != "")
            {
                lbName.Visible = true;
                lbName.Text = " کاربر: " + Db.tbName_in_DataBase + " " + Db.tbLast_in_DataBase;
                btnStart.Visible = true;
                lbNegPoints.Visible = true;
                lbPosPoints.Visible = true;
                lbNegPoints.Text = "امتیاز منفی: " + NPoitns.ToString();
                lbPosPoints.Text = "امتیاز مثبت: " + PPoints.ToString();
            }
            else
                MessageBox.Show("ابتدا مشخصات خود را وارد کنید");
            MessageBox.Show("(حال سطح بازی خود را از منوی تنظیمات انتخاب کنید(پیش فرض شما آسان طراحی شده");
        }

        private void انتخابرنگToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult TexCol = colorDialog1.ShowDialog();
            if (TexCol == DialogResult.OK)
                lbRead.ForeColor = colorDialog1.Color;
            else
                return;
        }

        private void انتخابفونتToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult TexFont = fontDialog1.ShowDialog();
            if (TexFont == DialogResult.OK)
                lbRead.Font = fontDialog1.Font;
            else return;
        }

        
        private void انتخابسطحToolStripMenuItem_Click(object sender, EventArgs e)
        {
           Dif = new Difficulty();
           Dif.ShowDialog();
            
           Hardship = Dif.RbResult;
            IsLvlChnge = true;
            
        }

        private void کاربرقدیمToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnPlay.Visible = false;
            AxWmPlayer.Visible = false;
            btnReadWord.Visible = false;

            Sw = File.AppendText(Dpath);

            if (IsLvlChnge)
            {
                

                Sw.WriteLine("Difficulty: " + Hardship);

                Sw.WriteLine("Negative Points: " + NPoitns.ToString());
                Sw.WriteLine("Positive Points: " + PPoints.ToString());
                Sw.WriteLine("---------------------------");
                IsLvlChnge = false;
            }

            else
            {
                Hardship = "آسان";
                Sw.WriteLine("Difficulty: " + Hardship);

                Sw.WriteLine("Negative Points: " + NPoitns.ToString());
                Sw.WriteLine("Positive Points: " + PPoints.ToString());
                Sw.WriteLine("---------------------------");



            }




            OL.ShowDialog();

            if (OL.IsOldUser)
            {


                lbName.Text = "کاربر: " + OL.omn + "" + OL.oml;
                Db.tbName_in_DataBase = OL.omn;
                Db.tbLast_in_DataBase = OL.oml;
                Hardship = OL.omh;
                Db.tbAge_in_DataBase = OL.Ageold;
                Db.tbIdNum_in_DataBase = OL.IdNumold;

                Sw.WriteLine("Name: " + Db.tbName_in_DataBase);
                Sw.WriteLine("LastName: " + Db.tbLast_in_DataBase);
                Sw.WriteLine("Id Number: " + Db.tbIdNum_in_DataBase);
                Sw.WriteLine("Age: " + Db.tbAge_in_DataBase);
                

                NPoitns = OL.nold;
                PPoints = OL.pold;

                lbNegPoints.Text = "امتیاز منفی: " + NPoitns.ToString();
                lbPosPoints.Text = "امتیاز مثبت: " + PPoints.ToString();
                
            }
            Sw.Close();
            i = 1;
            btnStart.Text = "شروع";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            string st = "C:\\Users\\lenovo\\Documents\\Sound recordings\\Recording.m4a";

            WMPLib.IWMPPlaylist playlist = AxWmPlayer.newPlaylist("test", "");
            if (lbRead.Text == "کسری")
            {
                st = "C:\\Users\\lenovo\\Documents\\Sound recordings\\Recording (2).m4a";
            }
            else if (lbRead.Text == "موبایل")
            {
                st = "C:\\Users\\lenovo\\Documents\\Sound recordings\\Recording (3).m4a";

            }
            else if (lbRead.Text == "نان")
            {
                st = "C:\\Users\\lenovo\\Documents\\Sound recordings\\Recording (4).m4a";

            }
            else if (lbRead.Text == "قستنطنیه")
            {
                st = "C:\\Users\\lenovo\\Documents\\Sound recordings\\Recording (5).m4a";

            }
            else if (lbRead.Text == "ارژانتین")
            {
                st = "C:\\Users\\lenovo\\Documents\\Sound recordings\\Recording (6).m4a";

            }

            WMPLib.IWMPMedia media = AxWmPlayer.newMedia(st);
                playlist.appendItem(media);
            
            AxWmPlayer.currentPlaylist = playlist;
        }

        private void MenuItem_click(object sender, EventArgs e)
        {
            string st = (sender as ToolStripMenuItem).Text;
            switch (st)
            {
                case "play":
                    AxWmPlayer.Ctlcontrols.play();
                    break;
                case "stop":
                    AxWmPlayer.Ctlcontrols.stop();
                    break;    
                case "pause":
                    AxWmPlayer.Ctlcontrols.pause();
                    break;
                case "next":
                    AxWmPlayer.Ctlcontrols.next();
                    break;
                case "previous":
                    AxWmPlayer.Ctlcontrols.previous();
                    break;
            }
        }

        private void playToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MenuItem_click(sender, e);
        
            }

        private void pauseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MenuItem_click(sender, e);

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MenuItem_click(sender, e);

        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            MenuItem_click(sender, e);

        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            MenuItem_click(sender, e);

        }

        private void btn9_Click(object sender, EventArgs e)
        {
            tbCheck.Text += btn9.Text;

        }

        private void btn7_Click(object sender, EventArgs e)
        {
            tbCheck.Text += btn7.Text;

        }

        private void btn6_Click(object sender, EventArgs e)
        {
            tbCheck.Text += btn6.Text;
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            tbCheck.Text += btn2.Text;

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            tbCheck.Text += btn1.Text;

        }

        private void btn4_Click(object sender, EventArgs e)
        {
            tbCheck.Text += btn4.Text;

        }

        private void btn8_Click(object sender, EventArgs e)
        {
            tbCheck.Text += btn8.Text;

        }

        private void btn10_Click(object sender, EventArgs e)
        {
            tbCheck.Text += btn10.Text;

        }

        private void btn5_Click(object sender, EventArgs e)
        {
            tbCheck.Text += btn5.Text;

        }

        private void btn3_Click(object sender, EventArgs e)
        {
            tbCheck.Text += btn3.Text;

        }

        
    }

    }


