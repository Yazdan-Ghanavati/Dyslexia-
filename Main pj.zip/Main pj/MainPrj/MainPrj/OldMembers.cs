﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainPrj
{
    public partial class OldMembers : Form
    {
        int del = 0;
        int i = 0;
        int[] NegCollective = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] PosCollective = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] AgeCollective = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] IdNumCollective = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        string[] NameCollective = new string[] { "", "", "", "", "", "", "", "", "", "" };
        string[] LastCollective = new string[] { "", "", "", "", "", "", "", "", "", "" };
        string[] HardShipCollective = new string[] { "", "", "", "", "", "", "", "", "", "" };
        DataBase Db = new DataBase();
        public string omn,oml,omh;//baraye emteghal esm karbar ghabli va...
        public bool IsOldUser = false;
        public int nold, pold,Ageold,IdNumold;//baraye enteghal emtiazat karbar ghabli

        private void LBoxData_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void Add(string Name, string Last, int IdNum, int Age, string HardSHip, int n, int p)
        {

            LBoxData.Items.Add("نام: " + Name);
            LBoxData.Items.Add("نام خانوادگی: " + Last);
            LBoxData.Items.Add("کد ملی: " + IdNum);
            LBoxData.Items.Add("سختی: " + HardSHip);
            LBoxData.Items.Add("سن: " + Age);
            LBoxData.Items.Add("امتیازات منفی: " + n);
            LBoxData.Items.Add("امتیازات مثبت: " + p);
            NegCollective[i] += n;
            PosCollective[i] += p;
            AgeCollective[i] += Age;
            IdNumCollective[i] += IdNum;
            NameCollective[i] += Name;
            LastCollective[i] += Last;
            HardShipCollective[i] += HardSHip;
            i++;
        }


        public OldMembers()
        {
            InitializeComponent();
        }
        
       


        private void btnDel_Click(object sender, EventArgs e)
        {
            DialogResult del = MessageBox.Show("آیا مطمئن هستید از حدف کاربر؟؟", "حذف", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (del == DialogResult.No)
                return;
            else
            {
                if (LBoxData.SelectedIndex == 0 || (LBoxData.SelectedIndex - 1) % 6 == 0)
                {
                    for (int n = LBoxData.SelectedIndex; n <= LBoxData.SelectedIndex + 7; n++)
                        LBoxData.Items.RemoveAt(0);
                }
                else
                    MessageBox.Show("فقط نام را انتخاب کنید");
                del++;
            }
        }

        private void btnOldMemChoose_Click(object sender, EventArgs e)
        {
            if (LBoxData.SelectedIndex == 0||(LBoxData.SelectedIndex-1)%6==0)
            {
                //omn = LBoxData.SelectedItem.ToString();
                if (LBoxData.SelectedIndex == 0)
                {
                    nold = NegCollective[0 + del + 1];
                    pold = PosCollective[0 + del + 1];
                    Ageold = AgeCollective[0 + del + 1];
                    IdNumold = IdNumCollective[0 + del + 1];
                    omn = NameCollective[0 + del + 1];
                    oml = LastCollective[0 + del + 1];
                    omh = HardShipCollective[0 + del + 1];
                }
                else
                {
                    nold = NegCollective[(LBoxData.SelectedIndex - 1) / 6 + del];
                    pold = PosCollective[(LBoxData.SelectedIndex - 1) / 6 + del];
                    Ageold = AgeCollective[(LBoxData.SelectedIndex - 1) / 6 + del];
                    IdNumold = AgeCollective[(LBoxData.SelectedIndex - 1) / 6 + del];
                    omn = NameCollective[(LBoxData.SelectedIndex - 1) / 6 + del];
                    oml = LastCollective[(LBoxData.SelectedIndex - 1) / 6 + del];
                    omh = HardShipCollective[(LBoxData.SelectedIndex - 1) / 6 + del];
                }
                IsOldUser = true;
            }
            else
                MessageBox.Show("فقط باید نام را انتخاب کنید");
        }

        
    }
}
