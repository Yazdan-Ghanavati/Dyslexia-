﻿namespace MainPrj
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnReadWord = new System.Windows.Forms.Button();
            this.lbRead = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.tbCheck = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.lbNegPoints = new System.Windows.Forms.Label();
            this.lbPosPoints = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbGuess = new System.Windows.Forms.Label();
            this.btnGuessCheck = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.گزینههاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بازیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.کاربرجدیدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خروجToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.کاربرقدیمToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تنظیماتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انتخابسطحToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.نمایشکلمهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انتخابفونتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انتخابرنگToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbName = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.AxWmPlayer = new AxWMPLib.AxWindowsMediaPlayer();
            this.objNotifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.objCMstrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.playToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pauseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnSpace = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnBe = new System.Windows.Forms.Button();
            this.btnPe = new System.Windows.Forms.Button();
            this.btnTe = new System.Windows.Forms.Button();
            this.btnSe = new System.Windows.Forms.Button();
            this.btnJim = new System.Windows.Forms.Button();
            this.btnChe = new System.Windows.Forms.Button();
            this.btnHe = new System.Windows.Forms.Button();
            this.btnKhe = new System.Windows.Forms.Button();
            this.btnDal = new System.Windows.Forms.Button();
            this.btnZal = new System.Windows.Forms.Button();
            this.btnRe = new System.Windows.Forms.Button();
            this.btnZe = new System.Windows.Forms.Button();
            this.btnZhe = new System.Windows.Forms.Button();
            this.btnSin = new System.Windows.Forms.Button();
            this.btnShin = new System.Windows.Forms.Button();
            this.btnSad = new System.Windows.Forms.Button();
            this.btnZad = new System.Windows.Forms.Button();
            this.btnTa = new System.Windows.Forms.Button();
            this.btnZa = new System.Windows.Forms.Button();
            this.btnEin = new System.Windows.Forms.Button();
            this.btnGhein = new System.Windows.Forms.Button();
            this.btnFe = new System.Windows.Forms.Button();
            this.btnGhaf = new System.Windows.Forms.Button();
            this.btnKaf = new System.Windows.Forms.Button();
            this.btnGaf = new System.Windows.Forms.Button();
            this.btnLam = new System.Windows.Forms.Button();
            this.btnMim = new System.Windows.Forms.Button();
            this.btnNoon = new System.Windows.Forms.Button();
            this.btnVav = new System.Windows.Forms.Button();
            this.btnHee = new System.Windows.Forms.Button();
            this.btnYe = new System.Windows.Forms.Button();
            this.btnAlef = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AxWmPlayer)).BeginInit();
            this.objCMstrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnReadWord
            // 
            this.btnReadWord.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnReadWord.Location = new System.Drawing.Point(29, 138);
            this.btnReadWord.Name = "btnReadWord";
            this.btnReadWord.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnReadWord.Size = new System.Drawing.Size(106, 35);
            this.btnReadWord.TabIndex = 0;
            this.btnReadWord.Text = "نمایش";
            this.toolTip1.SetToolTip(this.btnReadWord, "برای نمایش فشار دهید");
            this.btnReadWord.UseVisualStyleBackColor = true;
            this.btnReadWord.Click += new System.EventHandler(this.btnReadWord_Click);
            // 
            // lbRead
            // 
            this.lbRead.AutoSize = true;
            this.lbRead.Font = new System.Drawing.Font("B Roya", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbRead.Location = new System.Drawing.Point(40, 73);
            this.lbRead.Name = "lbRead";
            this.lbRead.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbRead.Size = new System.Drawing.Size(92, 27);
            this.lbRead.TabIndex = 1;
            this.lbRead.Text = "اسم خوانده شده";
            // 
            // tbCheck
            // 
            this.tbCheck.Font = new System.Drawing.Font("B Roya", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tbCheck.Location = new System.Drawing.Point(456, 94);
            this.tbCheck.Name = "tbCheck";
            this.tbCheck.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tbCheck.Size = new System.Drawing.Size(115, 34);
            this.tbCheck.TabIndex = 34;
            this.toolTip1.SetToolTip(this.tbCheck, "حدس خود را اینجا وارد کنید");
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnStart.Location = new System.Drawing.Point(220, 27);
            this.btnStart.Name = "btnStart";
            this.btnStart.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnStart.Size = new System.Drawing.Size(106, 35);
            this.btnStart.TabIndex = 39;
            this.btnStart.Text = "شروع بازی";
            this.toolTip1.SetToolTip(this.btnStart, "برای شروع کلیک کنید");
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // lbNegPoints
            // 
            this.lbNegPoints.AutoSize = true;
            this.lbNegPoints.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbNegPoints.Location = new System.Drawing.Point(64, 421);
            this.lbNegPoints.Name = "lbNegPoints";
            this.lbNegPoints.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbNegPoints.Size = new System.Drawing.Size(45, 32);
            this.lbNegPoints.TabIndex = 41;
            this.lbNegPoints.Text = "منفی";
            this.toolTip1.SetToolTip(this.lbNegPoints, "امتیاز منفی");
            // 
            // lbPosPoints
            // 
            this.lbPosPoints.AutoSize = true;
            this.lbPosPoints.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbPosPoints.Location = new System.Drawing.Point(175, 421);
            this.lbPosPoints.Name = "lbPosPoints";
            this.lbPosPoints.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbPosPoints.Size = new System.Drawing.Size(48, 32);
            this.lbPosPoints.TabIndex = 42;
            this.lbPosPoints.Text = "مثبت";
            this.toolTip1.SetToolTip(this.lbPosPoints, "امتیاز مثبت");
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbGuess
            // 
            this.lbGuess.AutoSize = true;
            this.lbGuess.Font = new System.Drawing.Font("B Roya", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbGuess.Location = new System.Drawing.Point(445, 60);
            this.lbGuess.Name = "lbGuess";
            this.lbGuess.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbGuess.Size = new System.Drawing.Size(131, 27);
            this.lbGuess.TabIndex = 37;
            this.lbGuess.Text = "حدس خود را وارد کنید";
            this.lbGuess.UseMnemonic = false;
            // 
            // btnGuessCheck
            // 
            this.btnGuessCheck.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnGuessCheck.Location = new System.Drawing.Point(456, 134);
            this.btnGuessCheck.Name = "btnGuessCheck";
            this.btnGuessCheck.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnGuessCheck.Size = new System.Drawing.Size(115, 39);
            this.btnGuessCheck.TabIndex = 38;
            this.btnGuessCheck.Text = "امتحان حدس";
            this.btnGuessCheck.UseVisualStyleBackColor = true;
            this.btnGuessCheck.Click += new System.EventHandler(this.btnGuessCheck_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.گزینههاToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1038, 24);
            this.menuStrip1.TabIndex = 40;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // گزینههاToolStripMenuItem
            // 
            this.گزینههاToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.بازیToolStripMenuItem,
            this.تنظیماتToolStripMenuItem});
            this.گزینههاToolStripMenuItem.Name = "گزینههاToolStripMenuItem";
            this.گزینههاToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.گزینههاToolStripMenuItem.Text = "گزینه ها";
            // 
            // بازیToolStripMenuItem
            // 
            this.بازیToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.کاربرجدیدToolStripMenuItem,
            this.خروجToolStripMenuItem,
            this.کاربرقدیمToolStripMenuItem});
            this.بازیToolStripMenuItem.Name = "بازیToolStripMenuItem";
            this.بازیToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.بازیToolStripMenuItem.Text = "بازی";
            // 
            // کاربرجدیدToolStripMenuItem
            // 
            this.کاربرجدیدToolStripMenuItem.Name = "کاربرجدیدToolStripMenuItem";
            this.کاربرجدیدToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.کاربرجدیدToolStripMenuItem.Text = "کاربر جدید";
            this.کاربرجدیدToolStripMenuItem.Click += new System.EventHandler(this.کاربرجدیدToolStripMenuItem_Click);
            // 
            // خروجToolStripMenuItem
            // 
            this.خروجToolStripMenuItem.Name = "خروجToolStripMenuItem";
            this.خروجToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.خروجToolStripMenuItem.Text = "خروج";
            this.خروجToolStripMenuItem.Click += new System.EventHandler(this.خروجToolStripMenuItem_Click);
            // 
            // کاربرقدیمToolStripMenuItem
            // 
            this.کاربرقدیمToolStripMenuItem.Name = "کاربرقدیمToolStripMenuItem";
            this.کاربرقدیمToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.کاربرقدیمToolStripMenuItem.Text = "کاربر قدیم";
            this.کاربرقدیمToolStripMenuItem.Click += new System.EventHandler(this.کاربرقدیمToolStripMenuItem_Click);
            // 
            // تنظیماتToolStripMenuItem
            // 
            this.تنظیماتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.انتخابسطحToolStripMenuItem,
            this.نمایشکلمهToolStripMenuItem});
            this.تنظیماتToolStripMenuItem.Name = "تنظیماتToolStripMenuItem";
            this.تنظیماتToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.تنظیماتToolStripMenuItem.Text = "تنظیمات";
            // 
            // انتخابسطحToolStripMenuItem
            // 
            this.انتخابسطحToolStripMenuItem.Name = "انتخابسطحToolStripMenuItem";
            this.انتخابسطحToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.انتخابسطحToolStripMenuItem.Text = "انتخاب سطح";
            this.انتخابسطحToolStripMenuItem.Click += new System.EventHandler(this.انتخابسطحToolStripMenuItem_Click);
            // 
            // نمایشکلمهToolStripMenuItem
            // 
            this.نمایشکلمهToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.انتخابفونتToolStripMenuItem,
            this.انتخابرنگToolStripMenuItem});
            this.نمایشکلمهToolStripMenuItem.Name = "نمایشکلمهToolStripMenuItem";
            this.نمایشکلمهToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.نمایشکلمهToolStripMenuItem.Text = "نمایش کلمه";
            // 
            // انتخابفونتToolStripMenuItem
            // 
            this.انتخابفونتToolStripMenuItem.Name = "انتخابفونتToolStripMenuItem";
            this.انتخابفونتToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.انتخابفونتToolStripMenuItem.Text = "انتخاب فونت";
            this.انتخابفونتToolStripMenuItem.Click += new System.EventHandler(this.انتخابفونتToolStripMenuItem_Click);
            // 
            // انتخابرنگToolStripMenuItem
            // 
            this.انتخابرنگToolStripMenuItem.Name = "انتخابرنگToolStripMenuItem";
            this.انتخابرنگToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.انتخابرنگToolStripMenuItem.Text = "انتخاب رنگ";
            this.انتخابرنگToolStripMenuItem.Click += new System.EventHandler(this.انتخابرنگToolStripMenuItem_Click);
            // 
            // lbName
            // 
            this.lbName.AutoSize = true;
            this.lbName.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbName.Location = new System.Drawing.Point(388, 421);
            this.lbName.Name = "lbName";
            this.lbName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbName.Size = new System.Drawing.Size(69, 31);
            this.lbName.TabIndex = 43;
            this.lbName.Text = "نام کاربر:";
            this.lbName.Visible = false;
            // 
            // AxWmPlayer
            // 
            this.AxWmPlayer.Enabled = true;
            this.AxWmPlayer.Location = new System.Drawing.Point(220, 346);
            this.AxWmPlayer.Name = "AxWmPlayer";
            this.AxWmPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("AxWmPlayer.OcxState")));
            this.AxWmPlayer.Size = new System.Drawing.Size(144, 47);
            this.AxWmPlayer.TabIndex = 44;
            // 
            // objNotifyIcon
            // 
            this.objNotifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("objNotifyIcon.Icon")));
            this.objNotifyIcon.Text = "notifyIcon1";
            this.objNotifyIcon.Visible = true;
            // 
            // objCMstrip
            // 
            this.objCMstrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.playToolStripMenuItem,
            this.pauseToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3});
            this.objCMstrip.Name = "objCMstrip";
            this.objCMstrip.Size = new System.Drawing.Size(120, 114);
            // 
            // playToolStripMenuItem
            // 
            this.playToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("playToolStripMenuItem.Image")));
            this.playToolStripMenuItem.Name = "playToolStripMenuItem";
            this.playToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.playToolStripMenuItem.Text = "play";
            this.playToolStripMenuItem.Click += new System.EventHandler(this.playToolStripMenuItem_Click);
            // 
            // pauseToolStripMenuItem
            // 
            this.pauseToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pauseToolStripMenuItem.Image")));
            this.pauseToolStripMenuItem.Name = "pauseToolStripMenuItem";
            this.pauseToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.pauseToolStripMenuItem.Text = "pause";
            this.pauseToolStripMenuItem.Click += new System.EventHandler(this.pauseToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem1.Image")));
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(119, 22);
            this.toolStripMenuItem1.Text = "stop";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem2.Image")));
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(119, 22);
            this.toolStripMenuItem2.Text = "next";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem3.Image")));
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(119, 22);
            this.toolStripMenuItem3.Text = "previous";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // btnPlay
            // 
            this.btnPlay.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnPlay.Location = new System.Drawing.Point(388, 355);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(108, 38);
            this.btnPlay.TabIndex = 46;
            this.btnPlay.Text = "شنیدن کلمه";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // btnSpace
            // 
            this.btnSpace.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSpace.Location = new System.Drawing.Point(767, 377);
            this.btnSpace.Name = "btnSpace";
            this.btnSpace.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnSpace.Size = new System.Drawing.Size(115, 39);
            this.btnSpace.TabIndex = 206;
            this.btnSpace.Text = "فاصله";
            this.btnSpace.UseVisualStyleBackColor = true;
            this.btnSpace.Visible = false;
            this.btnSpace.Click += new System.EventHandler(this.btnSpace_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnClear.Location = new System.Drawing.Point(706, 377);
            this.btnClear.Name = "btnClear";
            this.btnClear.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnClear.Size = new System.Drawing.Size(48, 39);
            this.btnClear.TabIndex = 205;
            this.btnClear.Text = "پاک";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Visible = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnBe
            // 
            this.btnBe.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnBe.Location = new System.Drawing.Point(901, 48);
            this.btnBe.Name = "btnBe";
            this.btnBe.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnBe.Size = new System.Drawing.Size(48, 39);
            this.btnBe.TabIndex = 204;
            this.btnBe.Text = "ب";
            this.btnBe.UseVisualStyleBackColor = true;
            this.btnBe.Visible = false;
            this.btnBe.Click += new System.EventHandler(this.btnBe_Click);
            // 
            // btnPe
            // 
            this.btnPe.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnPe.Location = new System.Drawing.Point(834, 48);
            this.btnPe.Name = "btnPe";
            this.btnPe.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnPe.Size = new System.Drawing.Size(48, 39);
            this.btnPe.TabIndex = 203;
            this.btnPe.Text = "پ";
            this.btnPe.UseVisualStyleBackColor = true;
            this.btnPe.Visible = false;
            this.btnPe.Click += new System.EventHandler(this.btnPe_Click);
            // 
            // btnTe
            // 
            this.btnTe.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnTe.Location = new System.Drawing.Point(767, 48);
            this.btnTe.Name = "btnTe";
            this.btnTe.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnTe.Size = new System.Drawing.Size(48, 39);
            this.btnTe.TabIndex = 202;
            this.btnTe.Text = "ت";
            this.btnTe.UseVisualStyleBackColor = true;
            this.btnTe.Visible = false;
            this.btnTe.Click += new System.EventHandler(this.btnTe_Click);
            // 
            // btnSe
            // 
            this.btnSe.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSe.Location = new System.Drawing.Point(706, 48);
            this.btnSe.Name = "btnSe";
            this.btnSe.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnSe.Size = new System.Drawing.Size(48, 39);
            this.btnSe.TabIndex = 201;
            this.btnSe.Text = "ث";
            this.btnSe.UseVisualStyleBackColor = true;
            this.btnSe.Visible = false;
            this.btnSe.Click += new System.EventHandler(this.btnSe_Click);
            // 
            // btnJim
            // 
            this.btnJim.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnJim.Location = new System.Drawing.Point(965, 103);
            this.btnJim.Name = "btnJim";
            this.btnJim.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnJim.Size = new System.Drawing.Size(48, 39);
            this.btnJim.TabIndex = 200;
            this.btnJim.Text = "ج";
            this.btnJim.UseVisualStyleBackColor = true;
            this.btnJim.Visible = false;
            this.btnJim.Click += new System.EventHandler(this.btnJim_Click);
            // 
            // btnChe
            // 
            this.btnChe.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnChe.Location = new System.Drawing.Point(901, 103);
            this.btnChe.Name = "btnChe";
            this.btnChe.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnChe.Size = new System.Drawing.Size(48, 39);
            this.btnChe.TabIndex = 199;
            this.btnChe.Text = "چ";
            this.btnChe.UseVisualStyleBackColor = true;
            this.btnChe.Visible = false;
            this.btnChe.Click += new System.EventHandler(this.btnChe_Click);
            // 
            // btnHe
            // 
            this.btnHe.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnHe.Location = new System.Drawing.Point(834, 103);
            this.btnHe.Name = "btnHe";
            this.btnHe.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnHe.Size = new System.Drawing.Size(48, 39);
            this.btnHe.TabIndex = 198;
            this.btnHe.Text = "ح";
            this.btnHe.UseVisualStyleBackColor = true;
            this.btnHe.Visible = false;
            this.btnHe.Click += new System.EventHandler(this.btnHe_Click);
            // 
            // btnKhe
            // 
            this.btnKhe.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnKhe.Location = new System.Drawing.Point(767, 103);
            this.btnKhe.Name = "btnKhe";
            this.btnKhe.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnKhe.Size = new System.Drawing.Size(48, 39);
            this.btnKhe.TabIndex = 197;
            this.btnKhe.Text = "خ";
            this.btnKhe.UseVisualStyleBackColor = true;
            this.btnKhe.Visible = false;
            this.btnKhe.Click += new System.EventHandler(this.btnKhe_Click);
            // 
            // btnDal
            // 
            this.btnDal.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnDal.Location = new System.Drawing.Point(706, 103);
            this.btnDal.Name = "btnDal";
            this.btnDal.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnDal.Size = new System.Drawing.Size(48, 39);
            this.btnDal.TabIndex = 196;
            this.btnDal.Text = "د";
            this.btnDal.UseVisualStyleBackColor = true;
            this.btnDal.Visible = false;
            this.btnDal.Click += new System.EventHandler(this.btnDal_Click);
            // 
            // btnZal
            // 
            this.btnZal.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnZal.Location = new System.Drawing.Point(965, 155);
            this.btnZal.Name = "btnZal";
            this.btnZal.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnZal.Size = new System.Drawing.Size(48, 39);
            this.btnZal.TabIndex = 195;
            this.btnZal.Text = "ذ";
            this.btnZal.UseVisualStyleBackColor = true;
            this.btnZal.Visible = false;
            this.btnZal.Click += new System.EventHandler(this.btnZal_Click);
            // 
            // btnRe
            // 
            this.btnRe.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnRe.Location = new System.Drawing.Point(901, 155);
            this.btnRe.Name = "btnRe";
            this.btnRe.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnRe.Size = new System.Drawing.Size(48, 39);
            this.btnRe.TabIndex = 194;
            this.btnRe.Text = "ر";
            this.btnRe.UseVisualStyleBackColor = true;
            this.btnRe.Visible = false;
            this.btnRe.Click += new System.EventHandler(this.btnRe_Click);
            // 
            // btnZe
            // 
            this.btnZe.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnZe.Location = new System.Drawing.Point(834, 155);
            this.btnZe.Name = "btnZe";
            this.btnZe.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnZe.Size = new System.Drawing.Size(48, 39);
            this.btnZe.TabIndex = 193;
            this.btnZe.Text = "ز";
            this.btnZe.UseVisualStyleBackColor = true;
            this.btnZe.Visible = false;
            this.btnZe.Click += new System.EventHandler(this.btnZe_Click);
            // 
            // btnZhe
            // 
            this.btnZhe.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnZhe.Location = new System.Drawing.Point(767, 155);
            this.btnZhe.Name = "btnZhe";
            this.btnZhe.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnZhe.Size = new System.Drawing.Size(48, 39);
            this.btnZhe.TabIndex = 192;
            this.btnZhe.Text = "ژ";
            this.btnZhe.UseVisualStyleBackColor = true;
            this.btnZhe.Visible = false;
            this.btnZhe.Click += new System.EventHandler(this.btnZhe_Click);
            // 
            // btnSin
            // 
            this.btnSin.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSin.Location = new System.Drawing.Point(706, 155);
            this.btnSin.Name = "btnSin";
            this.btnSin.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnSin.Size = new System.Drawing.Size(48, 39);
            this.btnSin.TabIndex = 191;
            this.btnSin.Text = "س";
            this.btnSin.UseVisualStyleBackColor = true;
            this.btnSin.Visible = false;
            this.btnSin.Click += new System.EventHandler(this.btnSin_Click);
            // 
            // btnShin
            // 
            this.btnShin.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnShin.Location = new System.Drawing.Point(965, 212);
            this.btnShin.Name = "btnShin";
            this.btnShin.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnShin.Size = new System.Drawing.Size(48, 39);
            this.btnShin.TabIndex = 190;
            this.btnShin.Text = "ش";
            this.btnShin.UseVisualStyleBackColor = true;
            this.btnShin.Visible = false;
            this.btnShin.Click += new System.EventHandler(this.btnShin_Click);
            // 
            // btnSad
            // 
            this.btnSad.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSad.Location = new System.Drawing.Point(901, 212);
            this.btnSad.Name = "btnSad";
            this.btnSad.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnSad.Size = new System.Drawing.Size(48, 39);
            this.btnSad.TabIndex = 189;
            this.btnSad.Text = "ص";
            this.btnSad.UseVisualStyleBackColor = true;
            this.btnSad.Visible = false;
            this.btnSad.Click += new System.EventHandler(this.btnSad_Click);
            // 
            // btnZad
            // 
            this.btnZad.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnZad.Location = new System.Drawing.Point(834, 212);
            this.btnZad.Name = "btnZad";
            this.btnZad.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnZad.Size = new System.Drawing.Size(48, 39);
            this.btnZad.TabIndex = 188;
            this.btnZad.Text = "ض";
            this.btnZad.UseVisualStyleBackColor = true;
            this.btnZad.Visible = false;
            this.btnZad.Click += new System.EventHandler(this.btnZad_Click);
            // 
            // btnTa
            // 
            this.btnTa.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnTa.Location = new System.Drawing.Point(767, 212);
            this.btnTa.Name = "btnTa";
            this.btnTa.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnTa.Size = new System.Drawing.Size(48, 39);
            this.btnTa.TabIndex = 187;
            this.btnTa.Text = "ط";
            this.btnTa.UseVisualStyleBackColor = true;
            this.btnTa.Visible = false;
            this.btnTa.Click += new System.EventHandler(this.btnTa_Click);
            // 
            // btnZa
            // 
            this.btnZa.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnZa.Location = new System.Drawing.Point(706, 212);
            this.btnZa.Name = "btnZa";
            this.btnZa.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnZa.Size = new System.Drawing.Size(48, 39);
            this.btnZa.TabIndex = 186;
            this.btnZa.Text = "ظ";
            this.btnZa.UseVisualStyleBackColor = true;
            this.btnZa.Visible = false;
            this.btnZa.Click += new System.EventHandler(this.btnZa_Click);
            // 
            // btnEin
            // 
            this.btnEin.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnEin.Location = new System.Drawing.Point(965, 268);
            this.btnEin.Name = "btnEin";
            this.btnEin.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnEin.Size = new System.Drawing.Size(48, 39);
            this.btnEin.TabIndex = 185;
            this.btnEin.Text = "ع";
            this.btnEin.UseVisualStyleBackColor = true;
            this.btnEin.Visible = false;
            this.btnEin.Click += new System.EventHandler(this.btnEin_Click);
            // 
            // btnGhein
            // 
            this.btnGhein.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnGhein.Location = new System.Drawing.Point(901, 268);
            this.btnGhein.Name = "btnGhein";
            this.btnGhein.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnGhein.Size = new System.Drawing.Size(48, 39);
            this.btnGhein.TabIndex = 184;
            this.btnGhein.Text = "غ";
            this.btnGhein.UseVisualStyleBackColor = true;
            this.btnGhein.Visible = false;
            this.btnGhein.Click += new System.EventHandler(this.btnGhein_Click);
            // 
            // btnFe
            // 
            this.btnFe.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnFe.Location = new System.Drawing.Point(834, 268);
            this.btnFe.Name = "btnFe";
            this.btnFe.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnFe.Size = new System.Drawing.Size(48, 39);
            this.btnFe.TabIndex = 183;
            this.btnFe.Text = "ف";
            this.btnFe.UseVisualStyleBackColor = true;
            this.btnFe.Visible = false;
            this.btnFe.Click += new System.EventHandler(this.btnFe_Click);
            // 
            // btnGhaf
            // 
            this.btnGhaf.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnGhaf.Location = new System.Drawing.Point(767, 268);
            this.btnGhaf.Name = "btnGhaf";
            this.btnGhaf.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnGhaf.Size = new System.Drawing.Size(48, 39);
            this.btnGhaf.TabIndex = 182;
            this.btnGhaf.Text = "ق";
            this.btnGhaf.UseVisualStyleBackColor = true;
            this.btnGhaf.Visible = false;
            this.btnGhaf.Click += new System.EventHandler(this.btnGhaf_Click);
            // 
            // btnKaf
            // 
            this.btnKaf.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnKaf.Location = new System.Drawing.Point(706, 268);
            this.btnKaf.Name = "btnKaf";
            this.btnKaf.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnKaf.Size = new System.Drawing.Size(48, 39);
            this.btnKaf.TabIndex = 181;
            this.btnKaf.Text = "ک";
            this.btnKaf.UseVisualStyleBackColor = true;
            this.btnKaf.Visible = false;
            this.btnKaf.Click += new System.EventHandler(this.btnKaf_Click);
            // 
            // btnGaf
            // 
            this.btnGaf.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnGaf.Location = new System.Drawing.Point(965, 323);
            this.btnGaf.Name = "btnGaf";
            this.btnGaf.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnGaf.Size = new System.Drawing.Size(48, 39);
            this.btnGaf.TabIndex = 180;
            this.btnGaf.Text = "گ";
            this.btnGaf.UseVisualStyleBackColor = true;
            this.btnGaf.Visible = false;
            this.btnGaf.Click += new System.EventHandler(this.btnGaf_Click);
            // 
            // btnLam
            // 
            this.btnLam.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnLam.Location = new System.Drawing.Point(901, 323);
            this.btnLam.Name = "btnLam";
            this.btnLam.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnLam.Size = new System.Drawing.Size(48, 39);
            this.btnLam.TabIndex = 179;
            this.btnLam.Text = "ل";
            this.btnLam.UseVisualStyleBackColor = true;
            this.btnLam.Visible = false;
            this.btnLam.Click += new System.EventHandler(this.btnLam_Click);
            // 
            // btnMim
            // 
            this.btnMim.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnMim.Location = new System.Drawing.Point(834, 323);
            this.btnMim.Name = "btnMim";
            this.btnMim.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnMim.Size = new System.Drawing.Size(48, 39);
            this.btnMim.TabIndex = 178;
            this.btnMim.Text = "م";
            this.btnMim.UseVisualStyleBackColor = true;
            this.btnMim.Visible = false;
            this.btnMim.Click += new System.EventHandler(this.btnMim_Click);
            // 
            // btnNoon
            // 
            this.btnNoon.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnNoon.Location = new System.Drawing.Point(767, 323);
            this.btnNoon.Name = "btnNoon";
            this.btnNoon.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnNoon.Size = new System.Drawing.Size(48, 39);
            this.btnNoon.TabIndex = 177;
            this.btnNoon.Text = "ن";
            this.btnNoon.UseVisualStyleBackColor = true;
            this.btnNoon.Visible = false;
            this.btnNoon.Click += new System.EventHandler(this.btnNoon_Click);
            // 
            // btnVav
            // 
            this.btnVav.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnVav.Location = new System.Drawing.Point(706, 323);
            this.btnVav.Name = "btnVav";
            this.btnVav.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnVav.Size = new System.Drawing.Size(48, 39);
            this.btnVav.TabIndex = 176;
            this.btnVav.Text = "و";
            this.btnVav.UseVisualStyleBackColor = true;
            this.btnVav.Visible = false;
            this.btnVav.Click += new System.EventHandler(this.btnVav_Click);
            // 
            // btnHee
            // 
            this.btnHee.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnHee.Location = new System.Drawing.Point(965, 377);
            this.btnHee.Name = "btnHee";
            this.btnHee.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnHee.Size = new System.Drawing.Size(48, 39);
            this.btnHee.TabIndex = 175;
            this.btnHee.Text = "ه";
            this.btnHee.UseVisualStyleBackColor = true;
            this.btnHee.Visible = false;
            this.btnHee.Click += new System.EventHandler(this.btnHee_Click);
            // 
            // btnYe
            // 
            this.btnYe.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnYe.Location = new System.Drawing.Point(901, 377);
            this.btnYe.Name = "btnYe";
            this.btnYe.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnYe.Size = new System.Drawing.Size(48, 39);
            this.btnYe.TabIndex = 174;
            this.btnYe.Text = "ی";
            this.btnYe.UseVisualStyleBackColor = true;
            this.btnYe.Visible = false;
            this.btnYe.Click += new System.EventHandler(this.btnYe_Click);
            // 
            // btnAlef
            // 
            this.btnAlef.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAlef.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnAlef.Location = new System.Drawing.Point(965, 48);
            this.btnAlef.Name = "btnAlef";
            this.btnAlef.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnAlef.Size = new System.Drawing.Size(48, 39);
            this.btnAlef.TabIndex = 173;
            this.btnAlef.Text = "الف";
            this.btnAlef.UseVisualStyleBackColor = true;
            this.btnAlef.Visible = false;
            this.btnAlef.Click += new System.EventHandler(this.btnAlef_Click);
            // 
            // btn10
            // 
            this.btn10.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn10.Location = new System.Drawing.Point(175, 119);
            this.btn10.Name = "btn10";
            this.btn10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn10.Size = new System.Drawing.Size(48, 39);
            this.btn10.TabIndex = 207;
            this.btn10.Text = "kw";
            this.btn10.UseVisualStyleBackColor = true;
            this.btn10.Visible = false;
            this.btn10.Click += new System.EventHandler(this.btn10_Click);
            // 
            // btn2
            // 
            this.btn2.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn2.Location = new System.Drawing.Point(574, 256);
            this.btn2.Name = "btn2";
            this.btn2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn2.Size = new System.Drawing.Size(48, 39);
            this.btn2.TabIndex = 208;
            this.btn2.Text = "kw";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Visible = false;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn3
            // 
            this.btn3.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn3.Location = new System.Drawing.Point(40, 247);
            this.btn3.Name = "btn3";
            this.btn3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn3.Size = new System.Drawing.Size(48, 39);
            this.btn3.TabIndex = 209;
            this.btn3.Text = "kw";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Visible = false;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn4
            // 
            this.btn4.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn4.Location = new System.Drawing.Point(503, 399);
            this.btn4.Name = "btn4";
            this.btn4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn4.Size = new System.Drawing.Size(48, 39);
            this.btn4.TabIndex = 210;
            this.btn4.Text = "kw";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Visible = false;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn5
            // 
            this.btn5.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn5.Location = new System.Drawing.Point(79, 23);
            this.btn5.Name = "btn5";
            this.btn5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn5.Size = new System.Drawing.Size(48, 39);
            this.btn5.TabIndex = 211;
            this.btn5.Text = "kw";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Visible = false;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn6
            // 
            this.btn6.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn6.Location = new System.Drawing.Point(631, 23);
            this.btn6.Name = "btn6";
            this.btn6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn6.Size = new System.Drawing.Size(48, 39);
            this.btn6.TabIndex = 212;
            this.btn6.Text = "kw";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Visible = false;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn7
            // 
            this.btn7.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn7.Location = new System.Drawing.Point(300, 225);
            this.btn7.Name = "btn7";
            this.btn7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn7.Size = new System.Drawing.Size(48, 39);
            this.btn7.TabIndex = 213;
            this.btn7.Text = "kw";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Visible = false;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn8
            // 
            this.btn8.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn8.Location = new System.Drawing.Point(364, 48);
            this.btn8.Name = "btn8";
            this.btn8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn8.Size = new System.Drawing.Size(48, 39);
            this.btn8.TabIndex = 214;
            this.btn8.Text = "kw";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Visible = false;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn9
            // 
            this.btn9.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn9.Location = new System.Drawing.Point(29, 377);
            this.btn9.Name = "btn9";
            this.btn9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn9.Size = new System.Drawing.Size(48, 39);
            this.btn9.TabIndex = 215;
            this.btn9.Text = "kw";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Visible = false;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn1
            // 
            this.btn1.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn1.Location = new System.Drawing.Point(642, 417);
            this.btn1.Name = "btn1";
            this.btn1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn1.Size = new System.Drawing.Size(48, 39);
            this.btn1.TabIndex = 216;
            this.btn1.Text = "kw";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Visible = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1038, 466);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn10);
            this.Controls.Add(this.btnSpace);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnBe);
            this.Controls.Add(this.btnPe);
            this.Controls.Add(this.btnTe);
            this.Controls.Add(this.btnSe);
            this.Controls.Add(this.btnJim);
            this.Controls.Add(this.btnChe);
            this.Controls.Add(this.btnHe);
            this.Controls.Add(this.btnKhe);
            this.Controls.Add(this.btnDal);
            this.Controls.Add(this.btnZal);
            this.Controls.Add(this.btnRe);
            this.Controls.Add(this.btnZe);
            this.Controls.Add(this.btnZhe);
            this.Controls.Add(this.btnSin);
            this.Controls.Add(this.btnShin);
            this.Controls.Add(this.btnSad);
            this.Controls.Add(this.btnZad);
            this.Controls.Add(this.btnTa);
            this.Controls.Add(this.btnZa);
            this.Controls.Add(this.btnEin);
            this.Controls.Add(this.btnGhein);
            this.Controls.Add(this.btnFe);
            this.Controls.Add(this.btnGhaf);
            this.Controls.Add(this.btnKaf);
            this.Controls.Add(this.btnGaf);
            this.Controls.Add(this.btnLam);
            this.Controls.Add(this.btnMim);
            this.Controls.Add(this.btnNoon);
            this.Controls.Add(this.btnVav);
            this.Controls.Add(this.btnHee);
            this.Controls.Add(this.btnYe);
            this.Controls.Add(this.btnAlef);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.AxWmPlayer);
            this.Controls.Add(this.lbName);
            this.Controls.Add(this.lbPosPoints);
            this.Controls.Add(this.lbNegPoints);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnGuessCheck);
            this.Controls.Add(this.lbGuess);
            this.Controls.Add(this.tbCheck);
            this.Controls.Add(this.lbRead);
            this.Controls.Add(this.btnReadWord);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Dislexy Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AxWmPlayer)).EndInit();
            this.objCMstrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReadWord;
        private System.Windows.Forms.Label lbRead;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox tbCheck;
        private System.Windows.Forms.Label lbGuess;
        private System.Windows.Forms.Button btnGuessCheck;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem گزینههاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem بازیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem کاربرجدیدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خروجToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem کاربرقدیمToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تنظیماتToolStripMenuItem;
        private System.Windows.Forms.Label lbNegPoints;
        private System.Windows.Forms.Label lbPosPoints;
        private System.Windows.Forms.Label lbName;
        private System.Windows.Forms.ToolStripMenuItem انتخابسطحToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem نمایشکلمهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem انتخابفونتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem انتخابرنگToolStripMenuItem;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.FontDialog fontDialog1;
        private AxWMPLib.AxWindowsMediaPlayer AxWmPlayer;
        private System.Windows.Forms.NotifyIcon objNotifyIcon;
        private System.Windows.Forms.ContextMenuStrip objCMstrip;
        private System.Windows.Forms.ToolStripMenuItem playToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pauseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnSpace;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnBe;
        private System.Windows.Forms.Button btnPe;
        private System.Windows.Forms.Button btnTe;
        private System.Windows.Forms.Button btnSe;
        private System.Windows.Forms.Button btnJim;
        private System.Windows.Forms.Button btnChe;
        private System.Windows.Forms.Button btnHe;
        private System.Windows.Forms.Button btnKhe;
        private System.Windows.Forms.Button btnDal;
        private System.Windows.Forms.Button btnZal;
        private System.Windows.Forms.Button btnRe;
        private System.Windows.Forms.Button btnZe;
        private System.Windows.Forms.Button btnZhe;
        private System.Windows.Forms.Button btnSin;
        private System.Windows.Forms.Button btnShin;
        private System.Windows.Forms.Button btnSad;
        private System.Windows.Forms.Button btnZad;
        private System.Windows.Forms.Button btnTa;
        private System.Windows.Forms.Button btnZa;
        private System.Windows.Forms.Button btnEin;
        private System.Windows.Forms.Button btnGhein;
        private System.Windows.Forms.Button btnFe;
        private System.Windows.Forms.Button btnGhaf;
        private System.Windows.Forms.Button btnKaf;
        private System.Windows.Forms.Button btnGaf;
        private System.Windows.Forms.Button btnLam;
        private System.Windows.Forms.Button btnMim;
        private System.Windows.Forms.Button btnNoon;
        private System.Windows.Forms.Button btnVav;
        private System.Windows.Forms.Button btnHee;
        private System.Windows.Forms.Button btnYe;
        private System.Windows.Forms.Button btnAlef;
        private System.Windows.Forms.Button btn10;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn1;
    }
}

