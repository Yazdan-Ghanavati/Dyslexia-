﻿namespace MainPrj
{
    partial class DataBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tbName = new System.Windows.Forms.TextBox();
            this.tbLastName = new System.Windows.Forms.TextBox();
            this.tbIdNum = new System.Windows.Forms.TextBox();
            this.tbAge = new System.Windows.Forms.TextBox();
            this.lbName2nd = new System.Windows.Forms.Label();
            this.lbLast2nd = new System.Windows.Forms.Label();
            this.lbIdNum2nd = new System.Windows.Forms.Label();
            this.lbAge2nd = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnTransfer = new System.Windows.Forms.Button();
            this.btnReturnDB = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbName
            // 
            this.tbName.Font = new System.Drawing.Font("B Roya", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tbName.Location = new System.Drawing.Point(62, 30);
            this.tbName.Name = "tbName";
            this.tbName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tbName.Size = new System.Drawing.Size(100, 34);
            this.tbName.TabIndex = 0;
            this.toolTip1.SetToolTip(this.tbName, "نام خود را اینجا وار کنید");
            // 
            // tbLastName
            // 
            this.tbLastName.Font = new System.Drawing.Font("B Roya", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tbLastName.Location = new System.Drawing.Point(62, 81);
            this.tbLastName.Name = "tbLastName";
            this.tbLastName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tbLastName.Size = new System.Drawing.Size(100, 34);
            this.tbLastName.TabIndex = 1;
            this.toolTip1.SetToolTip(this.tbLastName, "نام خانوادگی خود را اینجا وارد کنید");
            // 
            // tbIdNum
            // 
            this.tbIdNum.Font = new System.Drawing.Font("B Roya", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tbIdNum.Location = new System.Drawing.Point(62, 131);
            this.tbIdNum.Name = "tbIdNum";
            this.tbIdNum.PasswordChar = '*';
            this.tbIdNum.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tbIdNum.Size = new System.Drawing.Size(100, 34);
            this.tbIdNum.TabIndex = 2;
            this.toolTip1.SetToolTip(this.tbIdNum, "کد ملی خود را اینجا وارد کنید");
            // 
            // tbAge
            // 
            this.tbAge.Font = new System.Drawing.Font("B Roya", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tbAge.Location = new System.Drawing.Point(62, 184);
            this.tbAge.Name = "tbAge";
            this.tbAge.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tbAge.Size = new System.Drawing.Size(100, 34);
            this.tbAge.TabIndex = 3;
            this.toolTip1.SetToolTip(this.tbAge, "سن خود را اینجا وارد کنید");
            // 
            // lbName2nd
            // 
            this.lbName2nd.AutoSize = true;
            this.lbName2nd.Font = new System.Drawing.Font("B Roya", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbName2nd.Location = new System.Drawing.Point(206, 39);
            this.lbName2nd.Name = "lbName2nd";
            this.lbName2nd.Size = new System.Drawing.Size(26, 27);
            this.lbName2nd.TabIndex = 4;
            this.lbName2nd.Text = "نام";
            // 
            // lbLast2nd
            // 
            this.lbLast2nd.AutoSize = true;
            this.lbLast2nd.Font = new System.Drawing.Font("B Roya", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbLast2nd.Location = new System.Drawing.Point(183, 88);
            this.lbLast2nd.Name = "lbLast2nd";
            this.lbLast2nd.Size = new System.Drawing.Size(75, 27);
            this.lbLast2nd.TabIndex = 5;
            this.lbLast2nd.Text = "نام خانوادگی";
            // 
            // lbIdNum2nd
            // 
            this.lbIdNum2nd.AutoSize = true;
            this.lbIdNum2nd.Font = new System.Drawing.Font("B Roya", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbIdNum2nd.Location = new System.Drawing.Point(196, 138);
            this.lbIdNum2nd.Name = "lbIdNum2nd";
            this.lbIdNum2nd.Size = new System.Drawing.Size(48, 27);
            this.lbIdNum2nd.TabIndex = 6;
            this.lbIdNum2nd.Text = "کد ملی";
            // 
            // lbAge2nd
            // 
            this.lbAge2nd.AutoSize = true;
            this.lbAge2nd.Font = new System.Drawing.Font("B Roya", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbAge2nd.Location = new System.Drawing.Point(206, 191);
            this.lbAge2nd.Name = "lbAge2nd";
            this.lbAge2nd.Size = new System.Drawing.Size(30, 27);
            this.lbAge2nd.TabIndex = 7;
            this.lbAge2nd.Text = "سن";
            // 
            // btnTransfer
            // 
            this.btnTransfer.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnTransfer.Location = new System.Drawing.Point(44, 261);
            this.btnTransfer.Name = "btnTransfer";
            this.btnTransfer.Size = new System.Drawing.Size(137, 37);
            this.btnTransfer.TabIndex = 8;
            this.btnTransfer.Text = "انتقال اطلاعات";
            this.toolTip1.SetToolTip(this.btnTransfer, "برای انتقال مشخصات به لیست کلیک کنید");
            this.btnTransfer.UseVisualStyleBackColor = true;
            this.btnTransfer.Click += new System.EventHandler(this.btnTransfer_Click);
            // 
            // btnReturnDB
            // 
            this.btnReturnDB.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnReturnDB.Font = new System.Drawing.Font("B Roya", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnReturnDB.Location = new System.Drawing.Point(265, 307);
            this.btnReturnDB.Name = "btnReturnDB";
            this.btnReturnDB.Size = new System.Drawing.Size(157, 49);
            this.btnReturnDB.TabIndex = 9;
            this.btnReturnDB.Text = "بازگشت به منو اصلی";
            this.btnReturnDB.UseVisualStyleBackColor = true;
            // 
            // DataBase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 394);
            this.Controls.Add(this.btnReturnDB);
            this.Controls.Add(this.btnTransfer);
            this.Controls.Add(this.lbAge2nd);
            this.Controls.Add(this.lbIdNum2nd);
            this.Controls.Add(this.lbLast2nd);
            this.Controls.Add(this.lbName2nd);
            this.Controls.Add(this.tbAge);
            this.Controls.Add(this.tbIdNum);
            this.Controls.Add(this.tbLastName);
            this.Controls.Add(this.tbName);
            this.Name = "DataBase";
            this.Text = "DataBase";
            this.Load += new System.EventHandler(this.DataBase_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.TextBox tbLastName;
        private System.Windows.Forms.TextBox tbIdNum;
        private System.Windows.Forms.TextBox tbAge;
        private System.Windows.Forms.Label lbName2nd;
        private System.Windows.Forms.Label lbLast2nd;
        private System.Windows.Forms.Label lbIdNum2nd;
        private System.Windows.Forms.Label lbAge2nd;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btnTransfer;
        private System.Windows.Forms.Button btnReturnDB;
    }
}