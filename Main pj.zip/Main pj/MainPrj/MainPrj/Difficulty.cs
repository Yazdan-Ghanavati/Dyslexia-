﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MainPrj
{
    public partial class Difficulty : Form
    {
        StreamWriter Sw;
        string Dpath = "C:\\Users\\lenovo\\Documents\\PROJECT_CSHARP\\DataBase.txt";

        public string RbResult = "آسان";

        public Difficulty()
        {

            InitializeComponent();
              


        }

        private void btnReturnDiff_Click(object sender, EventArgs e)
        {
            
        }

        private void rbEasy_CheckedChanged(object sender, EventArgs e)
        {

            if (rbEasy.Checked)
            {

                RbResult = rbEasy.Text;
                
            }
        }

        private void rbModerate_CheckedChanged(object sender, EventArgs e)
        {

            if (rbModerate.Checked)
            {


                RbResult = rbModerate.Text;

               
            }
        }

        private void rbHard_CheckedChanged(object sender, EventArgs e)
        {


            if (rbHard.Checked)
            {

                RbResult = rbHard.Text;

               
            }
        }
    }
}
